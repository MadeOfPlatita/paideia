# Diario de desarrollo de Paideia

## Estado

Fase de definición. No se ha construido ni desplegado la aplicación. Este diario distingue conversación de diseño, decisiones y comprobaciones reales. No sustituye las instrucciones definitivas de entrega de la profesora.

## Herramienta utilizada

Hermes Agent como asistente conversacional para analizar el enunciado y precisar requisitos. En esta fase se ha leído IDEA.md, se han formulado preguntas y se han consultado fuentes públicas. No se han seleccionado aún proveedor LLM ni arquitectura de la aplicación.

## Entrada 1 — Lectura del planteamiento

### Prompt del usuario

> Lee el idea.md y haznos todas las preguntas que consideres necesarias

### Trabajo realizado

- Lectura del archivo IDEA.md del proyecto.
- Identificación de entregables: aplicación online, enlace en Wiki, código fuente, diario de desarrollo y demo presencial.
- Cuestionario sobre alcance, público, datos, IA, privacidad, alojamiento y diseño.

## Entrada 2 — Definición con el equipo

### Extractos de las respuestas del usuario

> Queremos tenerlo hecho en una semana

> Todo gratuito

> Paideia nombre

> Teníamos pensado como un triangulito que se llame Pai

> Un usuario compara alternativas y ve cómo cambian los escenarios con sus decisiones.

Los extractos anteriores no son la transcripción completa. Las decisiones y las cuestiones pendientes se consolidan en REQUISITOS.md.

### Decisiones recogidas

- Web educativa y de exploración financiera para mayores de edad, en español y orientada a España.
- Mascota Pai, perfil conversacional editable y chat posterior.
- Biblioteca amplia con información breve y detalle verificado al comparar.
- Deseo de datos actualizados diariamente y de servicios gratuitos, sujeto a viabilidad.
- Comparador, simuladores de interés simple/compuesto, escenarios, glosario y PDF opcional.
- Sin registro, perfil local borrable y minimización de datos.
- Demo cuyo peor caso de afluencia se estima en 100 usuarios concurrentes.

### Advertencias y decisiones no cerradas

- No se ha probado una fuente que cubra los productos deseados ni su actualización diaria.
- No se ha demostrado capacidad para 100 usuarios ni seleccionado API gratuita.
- Una preferencia por riesgo elevado no equivale a capacidad de asumir pérdidas.
- La experiencia del usuario no habilita a la aplicación como asesor profesional.
- La respuesta sobre contratación necesita aclaración; no se ha aprobado ejecutar operaciones.

## Fuentes consultadas durante la definición

- CNMV, evaluación de la idoneidad: https://cnmv.es/portal/inversor/idoneidad?lang=es
- CNMV, decisiones de inversión y entidades autorizadas: https://cnmv.es/portal/inversor/decisiones-inversion?lang=es
- Documentación de facturación y niveles de acceso de Gemini API: https://ai.google.dev/gemini-api/docs/billing

Estas consultas sirven para identificar restricciones, no acreditan cumplimiento legal ni garantizan cuotas o capacidad de un proveedor.

## Entrada 3 — Cierre del alcance inicial

### Respuestas del usuario

> 1. La simulación de contratación
> 2. Correcto
> 3. Si
> 4. Por ahora si, luego ya vamos estirando el chicle

### Decisiones confirmadas

- Incluir simulación de contratación, no limitarse a enlazar a entidades.
- Aceptar el último dato verificado si falla una actualización, con advertencia, fuente y fecha, y excluir datos inadecuados por antigüedad de las comparaciones.
- La aplicación publicada debe funcionar con los ordenadores del grupo apagados.
- Priorizar cuentas remuneradas, depósitos, letras/deuda pública, fondos y ETF; ampliar después según viabilidad.

### Criterios de seguridad para el diseño

- La simulación debe identificarse como tal, no ejecutar operaciones y utilizar datos ficticios, sin pedir credenciales, documentos personales ni pagos.
- No se han verificado todavía fuentes diarias gratuitas, capacidad del chat para 100 usuarios concurrentes ni alojamiento. La aprobación del alcance no prueba su viabilidad técnica.

## Entrada 4 — Investigación paralela y contraste

### Prompt del usuario

> Lanza todos los subagentes que puedas para investigar información, recursos, apis, repos, no seremos los primeros haciendo algo así

### Trabajo realizado

- Diez subagentes iniciales en paralelo, uno por área: cuentas/depósitos, deuda pública, fondos/ETF, LLM gratuita, alojamiento, MCP, repos similares, UX, rigor financiero y seguridad/calidad.
- El primer intento de fondos/ETF no entregó informe; se lanzó un subagente adicional con una estrategia de recuperación distinta.
- Resultado comprobado en disco: diez informes y diez JSON de fuentes. Agregación programática: 290 registros y 284 URLs distintas por comparación literal, conservando procedencia. No se presenta ese número como corroboración independiente de todos los datos.
- Se seleccionaron ocho repositorios de referencia; no se clonó ni ejecutó su código.
- El coordinador contrastó 19 URLs mediante GET públicos y guardó textos y metadatos. Entre ellas: términos Gemini, cuotas Cloudflare, documentación MCP/BdE/CNMV/Tesoro, README/licencias y tres endpoints estadísticos/de mercado.
- Se verificó el archivo de citas de la síntesis con evidencia literal; se corrigió un conflicto entre informes sobre los términos de reutilización de estadísticas del BdE.
- Se calcularon en Python escenarios teóricos de consumo de Neurons. No son pruebas de carga ni de calidad de modelos.

### Entregables

- `investigacion/00-SINTESIS.md`: conclusiones contrastadas, propuestas y límites.
- `investigacion/README.md`: índice de diez áreas.
- `investigacion/FUENTES_AGREGADAS.json`: fuentes deduplicadas con observaciones originales.
- `investigacion/evidencia-parental/`: textos y registro de comprobaciones directas.

### Límites y decisiones pendientes

No se encontraron evidencias suficientes de una API abierta gratuita que resuelva todo el catálogo contractual diario. La inferencia gratuita para cien usuarios sigue sin prueba. No se crearon cuentas, claves, despliegues ni aplicación; no se ejecutaron pruebas de carga. Proveedor, arquitectura y cambios de alcance son propuestas, no decisiones nuevas del grupo. Mantener productos reales verificados y no sustituir silenciosamente chat o catálogo por ejemplos ficticios.

## Registro a mantener al desarrollar

En cada bloque de trabajo se anotarán el prompt o su extracto identificado como tal, herramienta/modelo si se conoce, cambios realizados, decisiones, pruebas ejecutadas con su resultado real y limitaciones pendientes. No se anotarán claves ni información personal de prueba.
